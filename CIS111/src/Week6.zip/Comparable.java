public interface Comparable {

  public int compareTo(Object o);

}