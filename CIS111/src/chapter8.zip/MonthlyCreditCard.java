

/**
 * Driver for CreditCard.java file.
 * 
 * @author Max Knee
 */
public class MonthlyCreditCard {
    public static void main (String[]args){
        CreditCard open = new CreditCard();
        CreditCard month = new CreditCard(332, 1300, .025);
        double balance = month.setBalance();
        double shoes = 500;
        double firstPayment = 300;
        double dinner = 30;
        double shirts = 200;
        double secondPayment = 400;
        double balanceShoes = month.charge(month.setBalance(), shoes);
        double balanceFirstPayment = month.payment(balanceShoes, firstPayment);
        double balanceDinner = month.charge(balanceFirstPayment, dinner);
        double balanceShirts = month.charge(balanceDinner, shirts);
        double balanceSecondPayment = month.payment(balanceShirts, secondPayment);
        double eomBalance = month.monthlyInterest(balanceSecondPayment, month.getMonthlyInterestRate());
        
        System.out.printf("Balance after month %.2f", eomBalance);
        
        
    }
    
}
