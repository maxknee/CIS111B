import java.util.*;

public class Account {

  private int id;

  private double balance;

  private double annualInterestRate;

  private Date dateCreated;

  public Account() {
  }

  /**
   *
   * @param accountId 
   * @param startingBalance 
   * @param balance
   * @param annualInterestRate
   * @param dateCreated  
   */
  public Account (int accountId, double startingBalance, double startingAnnualInterestRate, Date accountDate){
      id = accountId;
      balance = startingBalance;
      annualInterestRate = startingAnnualInterestRate;
      dateCreated = accountDate;
      
      
  }
  public void createAccount(int id, double balance) {

  }

  public int setId() {

  return id;
  
  }

  public double setBalance() {
    
  return balance;
  }

  public double getAnnualInterestRate() {
  return annualInterestRate;
  }

  public Date getdateCreated() {

  return dateCreated;
  }

  public static double getMonthlyInterestRate(double annualInterestRate) {
      double monthlyInterest = annualInterestRate / 12;
  return monthlyInterest;
  }

  public double withdraw(double balance, double withdrawAmount) {
      double newBalance = balance - withdrawAmount;
  return newBalance;
  }

  public double deposit(double balance, double depositAmount) {
     double newBalance = balance + depositAmount;

  return newBalance;
  }

}

