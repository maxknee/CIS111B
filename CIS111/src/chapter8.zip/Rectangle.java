/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MKnee000
 */
public class Rectangle {
    public double width = 1;

    public double height = 1;

    public Rectangle() {
    }

    public Rectangle(double newHeight, double newWidth) {

    }

    public double getArea() {
        double area = width * height;
        return area;
    }

    public double getPerimeter() {
        double perimeter = width + height;
        return perimeter;
    }

    public static void main(String[] args){
        Rectangle rectangle1 = new Rectangle(4, 40);
        rectangle1.width = 4;
        rectangle1.height = 40;
        Rectangle rectangle2 = new Rectangle(3.5, 35.9);
        rectangle2.height = 35.9;
        rectangle2.width = 3.5;
        System.out.println("Width of Rectangle 1 " + rectangle1.width + " Height of Rectangle 1 " + rectangle1.height +
                " Area of Rectangle 1 " + rectangle1.getArea() + " Perimeter of Rectangle 1 " + rectangle1.getPerimeter());
        System.out.println("Width of Rectangle 2 " + rectangle2.width + " Height of Rectangle 2 " + rectangle2.height +
                " Area of Rectangle 2 " + rectangle2.getArea() + " Perimeter of Rectangle 2 " + rectangle2.getPerimeter());


    }
}
