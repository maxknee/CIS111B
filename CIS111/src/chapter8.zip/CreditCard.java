
/*
 * CreditCard.java class file.
 * This file is different than the 8.7 homework
 * It has some names changed to compensate for payments and charges on the account.
 * Also a monthly interest method has been added to calculate interest for the end of the month.
 * 
 */
public class CreditCard {

  private int id;

  private double balance;

  private double monthlyInterestRate;


  public CreditCard() {
  }

  
   
  public CreditCard (int accountId, double startingBalance, double startingMonthlyInterestRate){
      id = accountId;
      balance = startingBalance;
      monthlyInterestRate = startingMonthlyInterestRate;

      
      
  }
  public void createAccount(int id, double balance) {

  }

  public int setId() {

  return id;
  
  }

  public double setBalance() {
    
  return balance;
  }

  public double getMonthlyInterestRate() {
  return monthlyInterestRate;
  }


  public double payment(double balance, double paymentAmount) {
      double newBalance = balance - paymentAmount;
  return newBalance;
  }

  public double charge(double balance, double chargeAmount) {
     double newBalance = balance + chargeAmount;

  return newBalance;
  }
  public double monthlyInterest(double balance, double monthlyInterestRate){
      double newBalance = balance;
      if (balance > 0){
          double monthlyCharge = balance * monthlyInterestRate;
          newBalance = balance + monthlyCharge;
      }
      return newBalance;
  }

}

